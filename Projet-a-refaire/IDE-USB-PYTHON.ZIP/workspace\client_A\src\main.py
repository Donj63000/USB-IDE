"""Point d'entree minimal du projet client (exemple)."""


def main() -> None:
    # Exemple simple pour valider le build PyInstaller.
    print("Hello client")


if __name__ == "__main__":
    main()
